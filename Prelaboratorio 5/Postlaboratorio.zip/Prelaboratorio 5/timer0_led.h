/*
 * pwm_init.h
 *
 * Created: 24/04/2025 12:23:28 p. m.
 *  Author: Admin
 */ 


#ifndef TIMER0_LED_H_
#define TIMER0_LED_H_

#include <stdint.h>

void Timer0_LED_Init(void);
void LED_set(uint8_t brillo);

#endif
