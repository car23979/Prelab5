/*
 * pwm2.h
 *
 * Created: 11/04/2025 05:36:34 p. m.
 *  Author: David Carranza
 */ 

#ifndef TIMER1_SERVO2_H_
#define TIMER1_SERVO2_H_

#include <stdint.h>

void Timer1_Servo2_Init(void);
void SERVO2_set(uint16_t pulso);

#endif
