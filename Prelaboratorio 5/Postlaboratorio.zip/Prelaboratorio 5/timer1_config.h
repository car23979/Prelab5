/*
 * timer1_config.h
 *
 * Created: 24/04/2025 12:35:53 p. m.
 *  Author: Admin
 */ 


#ifndef TIMER1_CONFIG_H_
#define TIMER1_CONFIG_H_

void Timer1_Config_Init(void); // Configura solo Timer1 para los servos




#endif /* TIMER1_CONFIG_H_ */