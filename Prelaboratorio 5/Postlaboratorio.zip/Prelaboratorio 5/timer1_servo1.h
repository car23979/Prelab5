/*
 * pwm.h
 *
 * Created: 11/04/2025 01:35:17 p. m.
 *  Author: Admin
 */ 

#ifndef TIMER1_SERVO1_H_
#define TIMER1_SERVO1_H_

#include <stdint.h>

void Timer1_Servo1_Init(void);
void SERVO1_set(uint16_t pulso);

#endif
